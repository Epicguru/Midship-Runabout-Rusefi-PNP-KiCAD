#include "ui.h"
#include "ui_img_splash.h"

lv_obj_t * ui_splashScreen;
static lv_obj_t * ui_splashImg;
static lv_timer_t * ui_splashTimer;

// Static logo splash, shown for 3 seconds before fading into ui_mainScreen.
#define SPLASH_DURATION_MS 3000
#define SPLASH_FADE_MS      400

static void splash_timer_cb(lv_timer_t * timer) {
  // 'true' as the last argument auto-deletes ui_splashScreen once the
  // fade-to-mainScreen transition completes, freeing its memory.
  lv_scr_load_anim(ui_mainScreen, LV_SCR_LOAD_ANIM_FADE_ON, SPLASH_FADE_MS, 0, true);
  lv_timer_del(timer);
  ui_splashTimer = NULL;
}

void ui_splashScreen_screen_init(void) {
  ui_splashScreen = lv_obj_create(NULL);
  lv_obj_clear_flag(ui_splashScreen, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_set_style_bg_color(ui_splashScreen, lv_color_hex(0x000000), LV_PART_MAIN | LV_STATE_DEFAULT);
  lv_obj_set_style_bg_opa(ui_splashScreen, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
  lv_obj_set_style_border_width(ui_splashScreen, 0, LV_PART_MAIN | LV_STATE_DEFAULT);

  ui_splashImg = lv_img_create(ui_splashScreen);
  lv_img_set_src(ui_splashImg, &ui_img_splash);
  // Embedded natively at 800x480 (logo fitted/centered onto the full
  // canvas ahead of time, not stretched) - no runtime scaling at all, so
  // no zoom-related cost. It's also a static image with no per-frame
  // redraw, so even if it were zoomed the cost would only be paid once -
  // but native-res avoids any softness too.
  lv_obj_align(ui_splashImg, LV_ALIGN_CENTER, 0, 0);

  ui_splashTimer = lv_timer_create(splash_timer_cb, SPLASH_DURATION_MS, NULL);
  lv_timer_set_repeat_count(ui_splashTimer, 1);
}
