#ifndef UI_SPLASHSCREEN_H
#define UI_SPLASHSCREEN_H

#ifdef __cplusplus
extern "C" {
#endif

#include "lvgl.h"

extern lv_obj_t * ui_splashScreen;
void ui_splashScreen_screen_init(void);

#ifdef __cplusplus
} /*extern "C"*/
#endif

#endif
