#include "ui.h"
#include "ui_img_splash.h"

lv_obj_t * ui_splashScreen;
static lv_obj_t * ui_splashGif;
static lv_timer_t * ui_splashTimer;

// Your finalized GIF is 49 frames @ 10fps (~4.9s). This is a fixed timer
// rather than a GIF "finished" callback (LVGL v8's lv_gif doesn't expose a
// clean one) - it just needs to be >= the animation length. Adjust this if
// you change the source GIF's duration.
#define SPLASH_DURATION_MS 5200
#define SPLASH_FADE_MS      400

static void splash_timer_cb(lv_timer_t * timer) {
  // 'true' as the last argument auto-deletes ui_splashScreen once the
  // fade-to-mainScreen transition completes, freeing its memory.
  lv_scr_load_anim(ui_mainScreen, LV_SCR_LOAD_ANIM_FADE_ON, SPLASH_FADE_MS, 0, true);
  lv_timer_del(timer);
  ui_splashTimer = NULL;
}

void ui_splashScreen_screen_init(void) {
  ui_splashScreen = lv_obj_create(NULL);
  lv_obj_clear_flag(ui_splashScreen, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_set_style_bg_color(ui_splashScreen, lv_color_hex(0x000000), LV_PART_MAIN | LV_STATE_DEFAULT);
  lv_obj_set_style_bg_opa(ui_splashScreen, 255, LV_PART_MAIN | LV_STATE_DEFAULT);
  lv_obj_set_style_border_width(ui_splashScreen, 0, LV_PART_MAIN | LV_STATE_DEFAULT);

  ui_splashGif = lv_gif_create(ui_splashScreen);
  lv_gif_set_src(ui_splashGif, &ui_img_splash);
  // Now embedded natively at 800x480 - no zoom/scaling at runtime. The
  // earlier 2x zoom of a 400x240 asset was the cause of the slow
  // playback: LVGL's zoom is a real-time software affine transform
  // recomputed on every frame draw, which is heavy across a full-screen
  // canvas at 10fps on this hardware. Decoding a native-size GIF with no
  // scaling is far cheaper. Costs ~1.9MB of flash instead of 622KB.
  lv_obj_align(ui_splashGif, LV_ALIGN_CENTER, 0, 0);

  ui_splashTimer = lv_timer_create(splash_timer_cb, SPLASH_DURATION_MS, NULL);
  lv_timer_set_repeat_count(ui_splashTimer, 1);
}
