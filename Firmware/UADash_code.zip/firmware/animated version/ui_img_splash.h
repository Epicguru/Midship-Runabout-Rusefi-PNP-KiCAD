#ifndef UI_IMG_SPLASH_H
#define UI_IMG_SPLASH_H

#ifdef __cplusplus
extern "C" {
#endif

#include "lvgl.h"

LV_IMG_DECLARE(ui_img_splash);

#ifdef __cplusplus
} /*extern "C"*/
#endif

#endif
