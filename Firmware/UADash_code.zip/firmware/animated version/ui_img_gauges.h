#ifndef UI_IMG_GAUGES_H
#define UI_IMG_GAUGES_H

#ifdef __cplusplus
extern "C" {
#endif

#if defined(LV_LVGL_H_INCLUDE_SIMPLE)
#include "lvgl.h"
#else
#include "lvgl.h"
#endif

LV_IMG_DECLARE(ui_img_afr_gauge);
LV_IMG_DECLARE(ui_img_boost_gauge);
LV_IMG_DECLARE(ui_img_boost_needle);

#ifdef __cplusplus
} /*extern "C"*/
#endif

#endif
