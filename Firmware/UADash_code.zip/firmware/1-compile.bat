rem You can select dispaly board build options: JC8048W550C, WAVESHARE_S3_LCD5, WAVESHARE_S3_LCD7, Sunton_S3_LCD7

rem PartitionScheme changed from huge_app to custom: huge_app only allocates a
rem fixed 3MB app partition (it was designed for 4MB flash and doesn't scale
rem up just because FlashSize=8M is set), which the splash screen + gauge
rem images pushed past. custom reads partitions.csv (in this same folder),
rem which gives app0 a full 6MB on this board's 8MB flash.
arduino-cli -j16 compile -b esp32:esp32:esp32s3:FlashSize=8M,PartitionScheme=custom,PSRAM=opi --build-property "build.defines=-DBOARD_HAS_PSRAM -DWAVESHARE_S3_LCD7" --build-property compiler.optimization_flags=-Os firmware.ino --output-dir ./artifacts -v

rem arduino-cli -j16 compile -b esp32:esp32:esp32s3:UploadSpeed=115200,FlashSize=16M,PartitionScheme=app3M_fat9M_16MB,PSRAM=opi firmware.ino -v


rem arduino-cli -j16 compile -b esp32:esp32:esp32s3:FlashSize=16M,PartitionScheme=app3M_fat9M_16MB,PSRAM=opi,EventsCore=0 --build-property "build.defines=-DBOARD_HAS_PSRAM -D<display_define>" --build-property compiler.optimization_flags=-O2 firmware.ino --output-dir ./artifacts -v