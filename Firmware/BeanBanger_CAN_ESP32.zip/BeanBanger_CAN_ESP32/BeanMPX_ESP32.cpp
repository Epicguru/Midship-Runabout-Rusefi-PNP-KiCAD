#include "BeanMPX_ESP32.h"
#include "soc/gpio_struct.h"

// Fast direct-register GPIO access, bypassing digitalRead()/digitalWrite().
// Those Arduino-core functions go through several layers of pin-validity
// checks and lookups on ESP32 - fine for normal use, but potentially too
// slow to reliably fit inside this library's ~52us ISR timing budget.
// These do the same job with a single register read/write, the same
// technique the ESP32 core itself uses internally for timing-critical
// code (e.g. RMT, I2S). Handles both GPIO 0-31 and 32-39 pin ranges.
static inline void IRAM_ATTR fastPinWrite(uint8_t pin, uint8_t val) {
  if (pin < 32) {
    if (val) GPIO.out_w1ts = (1UL << pin);
    else GPIO.out_w1tc = (1UL << pin);
  } else {
    if (val) GPIO.out1_w1ts.val = (1UL << (pin - 32));
    else GPIO.out1_w1tc.val = (1UL << (pin - 32));
  }
}

static inline uint8_t IRAM_ATTR fastPinRead(uint8_t pin) {
  uint8_t val;
  if (pin < 32) {
    val = (GPIO.in >> pin) & 0x1;
  } else {
    val = (GPIO.in1.val >> (pin - 32)) & 0x1;
  }
#ifdef BEAN_RX_INVERT
  // Testing the hypothesis that the ESP32-side interface circuit presents
  // an inverted signal relative to what this code (ported faithfully from
  // AVR logic) expects - every received frame has been consistently wrong
  // from the very first bit, which fits a polarity inversion better than
  // random noise or timing drift.
  val = !val;
#endif
  return val;
}

// CRC: Polynomial = 8X + 4X + X + 1 (unchanged from the original library)
const uint8_t crctable[256] = {
    0x00, 0x13, 0x26, 0x35, 0x4C, 0x5F, 0x6A, 0x79, 0x98, 0x8B, 0xBE, 0xAD, 0xD4, 0xC7, 0xF2, 0xE1,
    0x23, 0x30, 0x05, 0x16, 0x6F, 0x7C, 0x49, 0x5A, 0xBB, 0xA8, 0x9D, 0x8E, 0xF7, 0xE4, 0xD1, 0xC2,
    0x46, 0x55, 0x60, 0x73, 0x0A, 0x19, 0x2C, 0x3F, 0xDE, 0xCD, 0xF8, 0xEB, 0x92, 0x81, 0xB4, 0xA7,
    0x65, 0x76, 0x43, 0x50, 0x29, 0x3A, 0x0F, 0x1C, 0xFD, 0xEE, 0xDB, 0xC8, 0xB1, 0xA2, 0x97, 0x84,
    0x8C, 0x9F, 0xAA, 0xB9, 0xC0, 0xD3, 0xE6, 0xF5, 0x14, 0x07, 0x32, 0x21, 0x58, 0x4B, 0x7E, 0x6D,
    0xAF, 0xBC, 0x89, 0x9A, 0xE3, 0xF0, 0xC5, 0xD6, 0x37, 0x24, 0x11, 0x02, 0x7B, 0x68, 0x5D, 0x4E,
    0xCA, 0xD9, 0xEC, 0xFF, 0x86, 0x95, 0xA0, 0xB3, 0x52, 0x41, 0x74, 0x67, 0x1E, 0x0D, 0x38, 0x2B,
    0xE9, 0xFA, 0xCF, 0xDC, 0xA5, 0xB6, 0x83, 0x90, 0x71, 0x62, 0x57, 0x44, 0x3D, 0x2E, 0x1B, 0x08,
    0x0B, 0x18, 0x2D, 0x3E, 0x47, 0x54, 0x61, 0x72, 0x93, 0x80, 0xB5, 0xA6, 0xDF, 0xCC, 0xF9, 0xEA,
    0x28, 0x3B, 0x0E, 0x1D, 0x64, 0x77, 0x42, 0x51, 0xB0, 0xA3, 0x96, 0x85, 0xFC, 0xEF, 0xDA, 0xC9,
    0x4D, 0x5E, 0x6B, 0x78, 0x01, 0x12, 0x27, 0x34, 0xD5, 0xC6, 0xF3, 0xE0, 0x99, 0x8A, 0xBF, 0xAC,
    0x6E, 0x7D, 0x48, 0x5B, 0x22, 0x31, 0x04, 0x17, 0xF6, 0xE5, 0xD0, 0xC3, 0xBA, 0xA9, 0x9C, 0x8F,
    0x87, 0x94, 0xA1, 0xB2, 0xCB, 0xD8, 0xED, 0xFE, 0x1F, 0x0C, 0x39, 0x2A, 0x53, 0x40, 0x75, 0x66,
    0xA4, 0xB7, 0x82, 0x91, 0xE8, 0xFB, 0xCE, 0xDD, 0x3C, 0x2F, 0x1A, 0x09, 0x70, 0x63, 0x56, 0x45,
    0xC1, 0xD2, 0xE7, 0xF4, 0x8D, 0x9E, 0xAB, 0xB8, 0x59, 0x4A, 0x7F, 0x6C, 0x15, 0x06, 0x33, 0x20,
    0xE2, 0xF1, 0xC4, 0xD7, 0xAE, 0xBD, 0x88, 0x9B, 0x7A, 0x69, 0x5C, 0x4F, 0x36, 0x25, 0x10, 0x03};

// Up to two BeanMPX instances (one per hardware timer), same limitation as
// the original which supported timer1 or timer2.
static BeanMPX *active_object0 = nullptr;
static BeanMPX *active_object1 = nullptr;

//
// Static ISR trampolines - required because timerAttachInterrupt() and
// attachInterrupt() need plain function pointers, not member functions.
//
static void IRAM_ATTR timer0_isr() {
  if (active_object0) {
    if (active_object0->_nextIsA()) {
      active_object0->onTimerA();
    } else {
      active_object0->onTimerB();
    }
  }
}
static void IRAM_ATTR timer1_isr() {
  if (active_object1) {
    if (active_object1->_nextIsA()) {
      active_object1->onTimerA();
    } else {
      active_object1->onTimerB();
    }
  }
}
static void IRAM_ATTR edge0_isr() {
  if (active_object0) active_object0->onEdge();
}
static void IRAM_ATTR edge1_isr() {
  if (active_object1) active_object1->onEdge();
}

// exposed just for the trampolines above
bool BeanMPX::_nextIsA() { return _next_is_A; }

//
// CRC helpers
//
uint8_t BeanMPX::gencrc(uint8_t bytes[], uint8_t length) {
  uint8_t crc = 0;
  for (uint8_t idx = 0; idx < length; idx++) {
    uint8_t data = (bytes[idx] ^ crc);
    crc = crctable[data];
  }
  return crc;
}

uint8_t BeanMPX::checkcrc(uint8_t bytes[], uint8_t length) {
  uint8_t crc = 0;
  for (uint8_t idx = 1; idx < length; idx++) { // skips SOF
    uint8_t data = (bytes[idx] ^ crc);
    crc = crctable[data];
  }
  return crc;
}

//
// Receive helpers (logic identical to the original library)
//
void BeanMPX::storeReceivedBit(uint8_t rx_pin_val, bool no_stuffing_bit) {
  if (no_stuffing_bit) {
    if (rx_pin_val) d |= i;
    i >>= 1;
    return;
  }

  if (s0 == 5 || s1 == 5) { // skip stuffing bit
    i <<= 1;
  } else {
    if (rx_pin_val) d |= i;
  }

  if (rx_pin_val) { s0++; s1 = 0; }
  else { s1++; s0 = 0; }

  i >>= 1;
}

void BeanMPX::storeReceivedByte() {
  _receive_buffer[_buffer_index] = d;
  d = 0;
  i = 0x80;
  _buffer_index++;
  if (_buffer_index > BUFFER_SIZE) {
    _buffer_index = 0;
    is_listining = false;
    msg_stage = 0;
  }
}

void BeanMPX::storeMessage(uint8_t *msg, uint8_t len, uint8_t msg_type) {
  if (mailbox_fill_level < MAILBOX_SIZE) {
    mailbox[mailbox_fill_level][0] = len;
    mailbox[mailbox_fill_level][1] = msg_type;
    memcpy(&mailbox[mailbox_fill_level][2], msg, len);
    mailbox_fill_level++;
  }
}

void BeanMPX::getMsg(uint8_t *buffer, uint8_t buffer_len) {
  memcpy(buffer, mailbox[0], buffer_len);
  for (int idx = 0; idx < mailbox_fill_level && idx < MAILBOX_SIZE; idx++) {
    memcpy(mailbox[idx], mailbox[idx + 1], BUFFER_SIZE);
  }
  if (mailbox_fill_level > 0) mailbox_fill_level--;
}

uint8_t BeanMPX::getStatus() { return mailbox_fill_level; }

//
// Receive routine - called every "A" phase timer tick (mirrors the original,
// which ran this from TIMER_COMPA)
//
void BeanMPX::receive() {
  if (is_transmitting) return;

  if (s0 > 7 || s1 > 7) {
    _buffer_index = 0;
    is_listining = false;
    msg_stage = 0;
    s0 = 0;
    s1 = 0;
    return;
  }

  uint8_t rx_pin_val = fastPinRead(_receivePin);

#ifdef BEANMPX_DEBUG_TIMING
  // Toggle on every sample so a scope shows exactly when/how often we
  // sample, overlaid against the real BEAN RX line.
  static uint8_t debugSampleState = 0;
  debugSampleState ^= 1;
  fastPinWrite(DEBUG_SAMPLE_PIN, debugSampleState);
#endif

  switch (msg_stage) {
    case 0:
      storeReceivedBit(rx_pin_val, true);
      if (!i) {
        d &= 1;
        storeReceivedByte();
        msg_stage++;
      }
      break;
    case 1:
      storeReceivedBit(rx_pin_val);
      if (!i) {
        msg_length = d & 0x0f;
        if (msg_length > 13) {
          msg_stage = 0;
          is_listining = false;
          timerAlarmDisable(_timer);
          _buffer_index = 0;
        }
        storeReceivedByte();
        msg_stage++;
      }
      break;
    case 2:
      storeReceivedBit(rx_pin_val);
      if (!i) {
        storeReceivedByte();
        if (msg_length == 1) { msg_stage++; break; }
        msg_length--;
      }
      break;
    case 3:
      storeReceivedBit(rx_pin_val);
      if (!i) {
        storeReceivedByte();
        s0 = 0; s1 = 0;
        msg_stage++;
      }
      break;
    case 4:
      storeReceivedBit(rx_pin_val, true);
      if (!i) {
        ack = (checkcrc((uint8_t*)_receive_buffer, _buffer_index) == 0) ? 0x40 : 0x80;
        if (d == 0x7E) {
          for (size_t a = 0; a < sizeof(acknowledge_did); a++) {
            if (_receive_buffer[2] == acknowledge_did[a]) {
              is_transmit_ack = true;
              break;
            }
          }
        }
        storeReceivedByte();
        msg_stage++;
      }
      break;
    case 5:
      storeReceivedBit(rx_pin_val, true);
      if (!i || (i & 0x1f) > 0) {
        storeReceivedByte();
        timerAlarmDisable(_timer);
        msg_stage = 0;
        is_listining = false;
        busy_timeout = millis();
        // 'R' = received with valid CRC, 'E' = received but CRC failed
        // (bus noise/corruption) - ack was already set from the CRC
        // check in case 4, just reuse it here rather than recomputing.
        storeMessage((uint8_t*)_receive_buffer, _buffer_index, (ack == 0x40) ? 'R' : 'E');
        _buffer_index = 0;
      }
      break;
  }
}

void BeanMPX::receiveAcknowledge() {
  if (!is_receive_ack) return;

  uint8_t rx_pin_val = fastPinRead(_receivePin);
  k >>= 1;

  if (!k) {
    k = 0x80;
    _transmit_buffer[_tx_buffer_index] = rsp;
    storeMessage((uint8_t*)_transmit_buffer, _tx_buffer_index + 1, 'T');

    if (rsp != 0x40 && tx_retry) {
      _tx_buffer_index = 0;
      j = 1;
      tx_retry--;
    } else {
      _tx_buffer_len = 0;
      tx_retry = 2;
    }
    is_receive_ack = false;
    busy_timeout = millis();
    rsp = 0;
  }
}

//
// Transmit routine - called every "B" phase timer tick (mirrors the
// original, which ran this from TIMER_COMPB)
//
void BeanMPX::transmit() {
  if (!(_tx_buffer_index < _tx_buffer_len)) {
    if (_tx_buffer_len > 1) {
      is_receive_ack = true;
      return;
    } else {
      if (is_transmitting) {
        is_transmitting = false;
        busy_timeout = millis();
        if (!is_listining) timerAlarmDisable(_timer);
        txSafetyState();
      }
      return;
    }
  }

  is_transmitting = true;
  uint8_t tx_pin_val = _transmit_buffer[_tx_buffer_index] & j;

  if (_tx_buffer_index < _tx_buffer_len - 1 && (tx_s0 == 5 || tx_s1 == 5)) {
    j <<= 1;
    if (tx_s0 == 5) {
      tx_pin_val = 0;
      fastPinWrite(_transmitPin, LOW);
    } else {
      tx_pin_val = 1;
      fastPinWrite(_transmitPin, HIGH);
    }
  } else {
    fastPinWrite(_transmitPin, tx_pin_val ? HIGH : LOW);
  }

  if (tx_pin_val) { tx_s0++; tx_s1 = 0; }
  else { tx_s1++; tx_s0 = 0; }

  j >>= 1;
  if (!j) {
    j = 0x80;
    _tx_buffer_index++;
  }
}

void BeanMPX::transmitAcknowledge() {
  if (!is_transmit_ack) return;

  uint8_t tx_pin_val = ack & l;
  fastPinWrite(_transmitPin, tx_pin_val ? HIGH : LOW);

  l >>= 1;
  if (!l || (l & 0x1f) > 0) {
    is_transmit_ack = false;
    busy_timeout = millis();
    l = 0x80;
    txSafetyState();
  }
}

void BeanMPX::txSafetyState() {
  fastPinWrite(_transmitPin, LOW);
}

//
// Timer phase handlers - called from the static trampolines. "A" phase =
// original TIMER1_COMPA_vect (receive + receiveAcknowledge). "B" phase =
// original TIMER1_COMPB_vect (transmit + transmitAcknowledge).
//
void IRAM_ATTR BeanMPX::onTimerA() {
  portENTER_CRITICAL_ISR(&_mux);
  receive();
  receiveAcknowledge();
  _next_is_A = false;
  portEXIT_CRITICAL_ISR(&_mux);
}

void IRAM_ATTR BeanMPX::onTimerB() {
  portENTER_CRITICAL_ISR(&_mux);
  transmit();
  transmitAcknowledge();
  _next_is_A = true;
  portEXIT_CRITICAL_ISR(&_mux);
}

//
// Edge (sync) handler - called on every RX pin edge (mirrors the original's
// PCINT-driven syncPulse()).
//
void IRAM_ATTR BeanMPX::onEdge() {
  portENTER_CRITICAL_ISR(&_mux);

  uint8_t rx_pin_val = fastPinRead(_receivePin);

#ifdef BEANMPX_DEBUG_TIMING
  // Brief pulse every time an edge is detected, so a scope shows how
  // accurately we're tracking real bus transitions.
  fastPinWrite(DEBUG_EDGE_PIN, HIGH);
  fastPinWrite(DEBUG_EDGE_PIN, LOW);
#endif

  if (!is_listining && rx_pin_val && !is_transmitting) {
    msg_stage = 0;
    // TEST: was i=2 (waits for a 2nd sample ~1 bit-period after the edge,
    // discarding the 1st - see storeReceivedBit's "d &= 1" masking in
    // case 0). SOF has been consistently wrong; testing whether ESP32's
    // higher GPIO interrupt latency (vs AVR's near-instant PCINT) is
    // pushing that delayed 2nd sample out of alignment. i=1 uses the
    // faster immediate sample instead.
    i = 1;
    d = 0;             // clear any stale partial byte from an abandoned previous frame
    _buffer_index = 0;  // defensive - should already be 0, but don't rely on every exit path having reset it
    // Clear the buffer CONTENTS too, not just the write position - a
    // short/spurious reception (bus noise right at the tail of a real
    // message) could otherwise complete early and report stale leftover
    // bytes from the previous message as if they were freshly received.
    memset((void*)_receive_buffer, 0, BUFFER_SIZE);
    is_listining = true;
    timerAlarmEnable(_timer);
  }

  if (rx_pin_val != _rx_prev_val) {
    _rx_prev_val = rx_pin_val;
    // Resync: jump the timer phase so the *next* tick is an "A" tick,
    // exactly HALF_PERIOD_US from now - this reproduces the original's
    // TCNT1 = 830 behaviour (which made the next compare match be COMPA).
    // EDGE_LATENCY_COMPENSATION_US accounts for the delay between the
    // real edge and this code actually executing.
    timerWrite(_timer, EDGE_LATENCY_COMPENSATION_US);
    _next_is_A = true;
  }

  portEXIT_CRITICAL_ISR(&_mux);
}

//
// Setup / public API
//
BeanMPX::BeanMPX() {}

void BeanMPX::begin(uint8_t rx, uint8_t tx, bool use_second_timer) {
  _receivePin = rx;
  _transmitPin = tx;

  pinMode(rx, INPUT);
  pinMode(tx, OUTPUT);
  txSafetyState();

#ifdef BEANMPX_DEBUG_TIMING
  pinMode(DEBUG_SAMPLE_PIN, OUTPUT);
  pinMode(DEBUG_EDGE_PIN, OUTPUT);
  fastPinWrite(DEBUG_SAMPLE_PIN, LOW);
  fastPinWrite(DEBUG_EDGE_PIN, LOW);
#endif

  // Timer: 1 MHz tick (1us). Alarm every HALF_PERIOD_US (52us), matching
  // the original's ~51.875us half-period. Divider = 80 assumes an 80MHz
  // APB clock (true for all current ESP32/ESP32-S variants under the
  // Arduino-ESP32 2.x core's default clock config).
  if (use_second_timer) {
    _timer = timerBegin(1, 80, true);
    timerAttachInterrupt(_timer, &timer1_isr, true);
    active_object1 = this;
  } else {
    _timer = timerBegin(0, 80, true);
    timerAttachInterrupt(_timer, &timer0_isr, true);
    active_object0 = this;
  }
  timerAlarmWrite(_timer, HALF_PERIOD_US, true);
  // Alarm is left disabled here; onEdge() enables it once a frame start is
  // detected, same as the original only enabling timer interrupts when
  // listening/transmitting.
  timerAlarmDisable(_timer);

  attachInterrupt(digitalPinToInterrupt(rx), use_second_timer ? edge1_isr : edge0_isr, CHANGE);
}

void BeanMPX::ackMsg(const uint8_t *destination_id, uint8_t len) {
  memcpy(acknowledge_did, destination_id, len);
}

uint8_t BeanMPX::available() { return mailbox_fill_level; }

void BeanMPX::sendMsg(const uint8_t *data, uint16_t datalen) {
  uint8_t frame[datalen + 4];
  tx_s0 = 0;
  tx_s1 = 0;

  frame[0] = 0x20 + datalen; // PRI ML
  for (uint8_t idx = 0; idx < datalen; idx++) {
    frame[idx + 1] = data[idx];
  }
  frame[datalen + 1] = gencrc(frame, datalen + 1); // CRC
  frame[datalen + 2] = 0x7e; // EOF

  for (uint8_t idx = sizeof(frame) - 1; idx > 0; idx--) {
    frame[idx] = frame[idx - 1];
  }
  frame[0] = 1;

  portENTER_CRITICAL(&_mux);
  memcpy((void*)_transmit_buffer, frame, sizeof(frame));
  _tx_buffer_len = sizeof(frame);
  _tx_buffer_index = 0;
  j = 1;
  // Resync + enable, matching the original's setTimerCounter() + enabling
  // the timer interrupt mask at the start of a send.
  timerWrite(_timer, 0);
  _next_is_A = true;
  timerAlarmEnable(_timer);
  portEXIT_CRITICAL(&_mux);
}