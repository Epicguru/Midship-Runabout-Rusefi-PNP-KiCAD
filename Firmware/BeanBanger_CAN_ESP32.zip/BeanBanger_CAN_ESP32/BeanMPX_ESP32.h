#ifndef BeanMPX_ESP32_h
#define BeanMPX_ESP32_h

#include <Arduino.h>
#include <inttypes.h>

/******************************************************************************
 * BeanMPX for ESP32
 * -----------------------------------------------------------------------
 * This is a port of fiztech-code's BeanMPX library (originally written for
 * ATmega328 / Arduino Nano) to the ESP32 (Arduino-ESP32 core, "classic" 2.x
 * timer API: timerBegin(num, divider, countUp) / timerAttachInterrupt /
 * timerAlarmWrite / timerAlarmEnable).
 *
 * WHAT CHANGED VS THE ORIGINAL AND WHY:
 *  - AVR Timer1/Timer2 (TCCR1A/OCR1A/OCR1B/TCNT1...) do not exist on ESP32.
 *    Replaced with one ESP32 hardware timer running at 1 MHz (1 tick = 1us),
 *    firing every 52us (half of the original ~103.75us bit period). An
 *    internal alternating flag reproduces the original's two-events-per-
 *    period behaviour (COMPB at the half period, COMPA at the full period),
 *    in the same order the original fired them.
 *  - AVR Pin Change Interrupts (PCICR/PCMSK/ISR(PCINT0_vect)) do not exist on
 *    ESP32. Replaced with attachInterrupt(pin, isr, CHANGE), which fires on
 *    both edges just like the original's PCINT group did for a single pin.
 *  - Direct AVR port register manipulation (portOutputRegister,
 *    digitalPinToBitMask, etc.) does not exist on ESP32 the same way.
 *    Replaced with digitalRead()/digitalWrite(). This is slightly slower
 *    than direct register writes but well within the timing budget here
 *    (bit period ~104us, GPIO calls take well under 1us on ESP32).
 *  - ESP32 is dual-core and interrupt-driven differently than AVR, so shared
 *    state touched by both the GPIO ISR and the timer ISR is protected with
 *    a portMUX_TYPE spinlock, and ISRs are marked IRAM_ATTR so they remain
 *    safe to run even during flash operations (e.g. if you add WiFi/OTA
 *    later).
 *
 * IMPORTANT: bit timing here is reproduced to within ~0.25us of the
 * original AVR timing, which should be comfortably inside BEAN's tolerance,
 * but this has NOT been bench-verified against a real BEAN bus/cluster.
 * Before connecting to a real vehicle, verify the TX waveform and RX
 * sampling points with a logic analyzer/scope against a known-good capture.
 ******************************************************************************/

#define MAILBOX_SIZE 8
#define BUFFER_SIZE 18
#define BEAN_FRAME_LENGTH 18

// ---- RX polarity test ----
// TESTED AND REVERTED: inverting made decoding worse, not better - this
// rules out a polarity mismatch as the cause. Leaving this here disabled
// in case it's useful for a different diagnosis later.
//#define BEAN_RX_INVERT

// ---- Optional scope/logic-analyzer debug instrumentation ----
// Uncomment to pulse two spare GPIOs so you can see exactly when the code
// samples a bit (DEBUG_SAMPLE_PIN) and when it detects a bus edge
// (DEBUG_EDGE_PIN), overlaid on the real BEAN RX line on your scope. Pick
// pins that aren't already used elsewhere in your sketch.
//#define BEANMPX_DEBUG_TIMING
#define DEBUG_SAMPLE_PIN 19
#define DEBUG_EDGE_PIN 21

// CRC table, same polynomial as the original (kept in flash via PROGMEM-
// compatible attribute; ESP32 doesn't need PROGMEM but it's harmless)
extern const uint8_t crctable[256];

class BeanMPX {
  public:
    BeanMPX();

    // rx, tx = GPIO pin numbers. use_second_timer: pass true to use hardware
    // timer 1 instead of timer 0, allowing two independent BeanMPX instances
    // (mirrors the original's use_timer2 flag for driving two buses at once).
    void begin(uint8_t rx, uint8_t tx, bool use_second_timer = false);
    void ackMsg(const uint8_t *data, uint8_t len);

    bool isBusy() {
      if (is_listining || is_transmitting || is_receive_ack || is_transmit_ack) {
        return true;
      }
      return (millis() - busy_timeout) < 2;
    }

    uint8_t available();
    void sendMsg(const uint8_t *data, uint16_t datalen);
    void getMsg(uint8_t *buffer, uint8_t buffer_len);
    uint8_t getStatus();

    // Called from the timer ISR (alternating "A"/"B" phase, matching the
    // original's COMPA/COMPB order) and from the GPIO edge ISR.
    void IRAM_ATTR onTimerA();
    void IRAM_ATTR onTimerB();
    void IRAM_ATTR onEdge();
    bool IRAM_ATTR _nextIsA(); // internal use by the static ISR trampolines

  private:
    // pins
    uint8_t _receivePin;
    uint8_t _transmitPin;
    uint8_t _rx_prev_val;

    // hardware timer
    hw_timer_t *_timer = nullptr;
    volatile bool _next_is_A = true; // which phase the next timer tick performs
    portMUX_TYPE _mux = portMUX_INITIALIZER_UNLOCKED;

    static const uint32_t HALF_PERIOD_US = 52;  // ~51.875us in the original
    // Compensates for ESP32 GPIO interrupt dispatch latency (higher than
    // AVR's near-instant PCINT response) at the moment of each edge
    // resync. Start at 0 and increase in small steps (try 2, 4, 6, 8us)
    // until frame decoding is clean - this needs empirical tuning since
    // actual ISR latency isn't something we can compute in advance.
    static const uint32_t EDGE_LATENCY_COMPENSATION_US = 4;

    // Receive state (semantics unchanged from the original library)
    volatile uint8_t msg_stage = 0;
    volatile bool is_listining = false;
    volatile uint8_t _receive_buffer[BUFFER_SIZE];
    volatile uint8_t _buffer_index = 0;
    volatile uint8_t d = 0;
    volatile uint8_t s0 = 0, s1 = 0;
    volatile uint16_t i = 1;
    volatile uint8_t msg_length = 0;

    // Transmit state
    volatile bool is_transmitting = false;
    volatile uint8_t _transmit_buffer[BUFFER_SIZE];
    volatile uint8_t _tx_buffer_index = 0;
    volatile uint8_t _tx_buffer_len = 0;
    volatile uint8_t tx_s0 = 0, tx_s1 = 0;
    volatile uint16_t j = 0x80;
    volatile uint8_t tx_retry = 2;

    // Acknowledge state
    uint8_t acknowledge_did[10];
    volatile bool is_receive_ack = false;
    volatile uint8_t rsp = 0;
    volatile uint16_t k = 0x80;
    volatile bool is_transmit_ack = false;
    volatile uint8_t ack = 0x40;
    volatile uint16_t l = 0x80;

    // Output mailbox
    uint8_t mailbox[MAILBOX_SIZE][BUFFER_SIZE + 2] = {0};
    uint8_t mailbox_fill_level = 0;

    volatile uint32_t busy_timeout = 0;

    uint8_t gencrc(uint8_t bytes[], uint8_t length);
    uint8_t checkcrc(uint8_t bytes[], uint8_t length);

    void storeReceivedBit(uint8_t rx_pin_val, bool no_stuffing_bit = false);
    void storeReceivedByte();
    void storeMessage(uint8_t *msg, uint8_t len, uint8_t msg_type = 0);
    void receive();
    void receiveAcknowledge();

    void transmit();
    void transmitAcknowledge();
    void txSafetyState();
    void resyncTimer();
};

#endif