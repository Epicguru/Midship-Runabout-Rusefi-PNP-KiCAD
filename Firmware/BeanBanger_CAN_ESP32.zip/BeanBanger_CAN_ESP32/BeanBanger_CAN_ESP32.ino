// ============================================================================
// BeanBanger_CAN_ESP32.ino
// CAN-sourced version: reads coolant temp, oil pressure, and alternator/
// charge status from rusEFI's CAN broadcast instead of analog/digital
// inputs, then relays them to the Toyota cluster over BEAN exactly as
// before.
//
// Requires BeanMPX_ESP32.h/.cpp alongside this sketch.
// Requires an ESP32 with a CAN transceiver (SN65HVD230, TJA1050, etc.)
// wired to two GPIOs - you said this is already wired, so set CAN_TX_PIN/
// CAN_RX_PIN below to match.
// ============================================================================
//
// WHERE THIS DATA COMES FROM - rusEFI's CAN broadcast
// -----------------------------------------------------------------------
// rusEFI has a built-in "verbose" CAN broadcast (what TunerStudio/
// third-party dashboards like Speedy Digital Cluster read). It starts at
// CAN ID 0x200 by default (engineConfiguration->verboseCanBaseAddress -
// change RUSEFI_CAN_BASE below if you've customized this in TunerStudio)
// and sends a fixed sequence of messages, each 8 bytes, standard 11-bit
// IDs (unless you've enabled 29-bit "rusefiVerbose29b").
//
// Messages used:
//   RUSEFI_MSG_SPEEDS   (base+1): bytes[0-1] = RPM, u16 LE, direct RPM
//   RUSEFI_MSG_SENSORS1 (base+3): byte[2]    = coolant temp, u8, +offset
//   RUSEFI_MSG_SENSORS2 (base+4): bytes[2-3] = oil pressure, u16 LE
//                                  bytes[6-7] = battery voltage, u16 LE
// ============================================================================

#include "driver/twai.h"
#include "BeanMPX_ESP32.h"

// ---- CAN transceiver pins - set to match your existing wiring ----
#define CAN_TX_PIN GPIO_NUM_25
#define CAN_RX_PIN GPIO_NUM_14

// ---- rusEFI CAN broadcast IDs ----
#define RUSEFI_CAN_BASE     0x200   // change if verboseCanBaseAddress isn't default
#define RUSEFI_MSG_SPEEDS   (RUSEFI_CAN_BASE + 1)
#define RUSEFI_MSG_SENSORS1 (RUSEFI_CAN_BASE + 3)
#define RUSEFI_MSG_SENSORS2 (RUSEFI_CAN_BASE + 4)

// ---- Scale factors - confirmed directly from rusEFI_CAN_verbose.dbc ----
// CoolantTemp: scale=1, offset=-40  -> degrees C = raw - 40
#define RUSEFI_TEMP_OFFSET     40.0f
#define RUSEFI_PRESSURE_SCALE  0.03333333f
#define RUSEFI_VOLTAGE_SCALE   0.001f

// ---- Warning-light thresholds (replaces the old physical switches) ----
#define OIL_PRESSURE_WARN_KPA 50.0f   // below this + engine running = oil light on
#define CHARGE_WARN_VOLTS_ENGINE_OFF     13.0f  
#define CHARGE_WARN_VOLTS_ENGINE_ON      11.8f

// ---- BEAN pins (same as the analog/digital port) ----
#define BEAN_RX_PIN 16
#define BEAN_TX_PIN 17

// ---- AC clutch/fan control ----
// Engages both outputs only when ALL of: AC is demanded via the BEAN
// message above, engine RPM is over AC_MIN_RPM, and the pressure switch
// reads OK (HIGH).
#define AC_CLUTCH_RELAY_PIN 18
#define AC_FAN_PIN 19
#define AC_PRESSURE_SWITCH_PIN 21
#define AC_MIN_RPM 700.0f
// NOTE: pin 21 is also used by the library's optional DEBUG_EDGE_PIN
// scope instrumentation (BeanMPX_ESP32.h) - that's disabled by default,
// but if you ever re-enable BEANMPX_DEBUG_TIMING, move one of the two.

// ---- BEAN -> CAN bridge: A/C compressor solenoid relay state ----
// Decoded from your sniffed frames:
//   01 63 13 D7 00 5E 7E 40  -> compressor relay off (data byte = 0x00)
//   01 A3 13 D7 40 B4 7E 40  -> compressor relay on  (data byte = 0x40)
// DID=0x13, MID=0xD7 identify the message; bit 6 (0x40) of the data byte
// is the A/C compressor solenoid relay enable - this is the vehicle's own
// commanded output (after its own interlocks/pressure switch logic have
// already been applied), not just raw driver button state. (The PRI/ML
// byte, 0x63 vs 0xA3, is BEAN's own alternating priority/retry bit, not
// part of this signal - ignored.)
#define BEAN_AC_DID 0x13
#define BEAN_AC_MID 0xD7
#define BEAN_AC_COMPRESSOR_RELAY_BIT 0x40

// CAN ID your rusEFI Lua script listens on for the AC request
#define AC_REQUEST_CAN_ID 0x353
// ASSUMPTION: "local byte 8 = data[8]" reads as Lua's 1-indexed array
// notation, i.e. the 8th byte = index 7 in a normal 0-indexed C array,
// set to 1 for AcRequestState(true) / 0 for AcRequestState(false). If
// your Lua script doesn't react, this is the first thing to check -
// print out the raw frame on the rusEFI side and compare.
#define AC_REQUEST_BYTE_INDEX 7

#define RX_BUFFER_SIZE 20
uint8_t bean_rx_buffer[RX_BUFFER_SIZE];
bool lastAcState = false;
bool acStateKnown = false;

BeanMPX bean;

uint8_t engTemp[] = {0x62, 0x2C, 0x00}; // Engine Temp 90-255 deadzone 165-212
uint8_t lights[]  = {0x62, 0xD4, 0x00}; // BATT, OIL --11---- (32,16)
uint32_t timer = 0;
// Non-blocking send sequence state: 0 = idle/ready to start a new cycle,
// 1 = engTemp sent, waiting for the bus to be free before sending lights.
uint8_t gaugeSendStep = 0;

// Latest values decoded from CAN, updated as messages arrive
volatile float canRpm = 0;
volatile float canCoolantC = 0;
volatile float canOilPressureKpa = 0;
volatile float canBattVolts = 0;
volatile uint32_t lastCanRxMillis = 0;

void setup() {
  Serial.begin(115200);
  bean.begin(BEAN_RX_PIN, BEAN_TX_PIN);

  pinMode(AC_CLUTCH_RELAY_PIN, OUTPUT);
  pinMode(AC_FAN_PIN, OUTPUT);
  digitalWrite(AC_CLUTCH_RELAY_PIN, LOW); // start with both outputs off
  digitalWrite(AC_FAN_PIN, LOW);
  pinMode(AC_PRESSURE_SWITCH_PIN, INPUT); // assumes external circuit drives a defined HIGH/LOW

  // The factory engine ECU (DID 0x13) has been removed from this car -
  // but other BEAN nodes (like the A/C control panel) still transmit
  // messages addressed to it and expect an ACK/NAK response. Without one,
  // the sending device gets no confirmation its message was received,
  // which can cause retries/erratic behavior on its end. Since this
  // ESP32 is already standing in for the removed ECU's role (reading its
  // sensor inputs via CAN), it should also take over acknowledging
  // messages addressed to its old bus address.
  uint8_t ackDids[] = { BEAN_AC_DID };
  bean.ackMsg(ackDids, sizeof(ackDids));

  // --- TWAI (CAN) setup: 500 kbps, normal mode ---
  twai_general_config_t g_config = TWAI_GENERAL_CONFIG_DEFAULT(CAN_TX_PIN, CAN_RX_PIN, TWAI_MODE_NORMAL);
  twai_timing_config_t t_config = TWAI_TIMING_CONFIG_500KBITS();
  twai_filter_config_t f_config = TWAI_FILTER_CONFIG_ACCEPT_ALL(); // filtered in software below

  if (twai_driver_install(&g_config, &t_config, &f_config) != ESP_OK) {
    Serial.println("CAN driver install failed");
  }
  if (twai_start() != ESP_OK) {
    Serial.println("CAN start failed");
  }
}

void handleCanFrame(const twai_message_t &msg) {
  lastCanRxMillis = millis();

  if (msg.identifier == RUSEFI_MSG_SPEEDS && msg.data_length_code >= 2) {
    canRpm = msg.data[0] | (msg.data[1] << 8);
  } else if (msg.identifier == RUSEFI_MSG_SENSORS1 && msg.data_length_code >= 3) {
    canCoolantC = (float)msg.data[2] - RUSEFI_TEMP_OFFSET;
  } else if (msg.identifier == RUSEFI_MSG_SENSORS2 && msg.data_length_code >= 8) {
    uint16_t rawOilP = msg.data[2] | (msg.data[3] << 8);
    uint16_t rawVbatt = msg.data[6] | (msg.data[7] << 8);
    canOilPressureKpa = rawOilP * RUSEFI_PRESSURE_SCALE;
    canBattVolts = rawVbatt * RUSEFI_VOLTAGE_SCALE;
  }
}

void pollCan() {
  twai_message_t msg;
  // Drain whatever's waiting, non-blocking-ish (0 tick wait)
  while (twai_receive(&msg, 0) == ESP_OK) {
    handleCanFrame(msg);
  }
}

// Transmits the AC request state to rusEFI over CAN, standard 11-bit ID.
void sendAcRequestCan(bool acOn) {
  twai_message_t txMsg = {};
  txMsg.identifier = AC_REQUEST_CAN_ID;
  txMsg.data_length_code = 8;
  txMsg.extd = 0; // standard 11-bit frame (0x353 fits in 11 bits)
  for (int idx = 0; idx < 8; idx++) txMsg.data[idx] = 0;
  txMsg.data[AC_REQUEST_BYTE_INDEX] = acOn ? 1 : 0;

  if (twai_transmit(&txMsg, pdMS_TO_TICKS(10)) != ESP_OK) {
    Serial.println("CAN TX failed (AC request)");
  }
}

// Checks a received BEAN frame for the A/C compressor solenoid relay
// state and updates lastAcState/acStateKnown. Ignores frames that failed
// their CRC check (bean_rx_buffer[1] != 'R') - a corrupted frame could
// otherwise flip a data bit and look like a real state change. Does NOT
// send anything over CAN itself - see updateAcOutputs(), which sends
// only once the full RPM/pressure-switch logic has also been applied.
void checkBeanAcMessage() {
  // Layout after BeanMPX::getMsg(): [0]=len [1]=type('R'=valid CRC,
  // 'E'=CRC failed) [2]=SOF [3]=PRI/ML [4]=DID [5]=MID [6]=data0 ...
  if (bean_rx_buffer[1] != 'R') return; // discard corrupted frames

  if (bean_rx_buffer[4] == BEAN_AC_DID && bean_rx_buffer[5] == BEAN_AC_MID) {
    bool compressorOn = (bean_rx_buffer[6] & BEAN_AC_COMPRESSOR_RELAY_BIT) != 0;
    if (!acStateKnown || compressorOn != lastAcState) {
      lastAcState = compressorOn;
      acStateKnown = true;
      Serial.print("AC compressor relay (BEAN) -> ");
      Serial.println(compressorOn ? "ON" : "OFF");
    }
  }
}

// Engages the AC clutch relay and fan outputs, and sends the CAN request
// to rusEFI, only when ALL of: AC is demanded (from the BEAN compressor
// relay message), engine RPM is above AC_MIN_RPM, and the pressure
// switch reads OK (HIGH). Re-evaluated every loop pass (not gated behind
// the once-per-second gauge timer) so a pressure fault or the engine
// stalling cuts everything immediately. The CAN message reflects this
// final gated decision, not just the raw incoming BEAN demand.
bool lastSentAcState = false;
bool acSentStateKnown = false;

void updateAcOutputs() {
  bool acDemanded = acStateKnown && lastAcState;
  bool engineRunning = canRpm > AC_MIN_RPM;
  bool pressureOk = digitalRead(AC_PRESSURE_SWITCH_PIN) == HIGH;

  bool enableAc = acDemanded && engineRunning && pressureOk;

  digitalWrite(AC_CLUTCH_RELAY_PIN, enableAc ? HIGH : LOW);
  digitalWrite(AC_FAN_PIN, enableAc ? HIGH : LOW);

  // Only send the CAN request when this final, gated decision actually
  // changes - not on every loop pass, and not just because the raw BEAN
  // demand changed if RPM/pressure would have blocked it anyway.
  if (!acSentStateKnown || enableAc != lastSentAcState) {
    sendAcRequestCan(enableAc);
    lastSentAcState = enableAc;
    acSentStateKnown = true;
    Serial.print("AC request CAN (gated) -> ");
    Serial.println(enableAc ? "ON" : "OFF");
  }
}

void loop() {
  pollCan();
  updateAcOutputs();

  // Check for any received BEAN frames (e.g. the A/C button message) and
  // bridge relevant ones to CAN. Drains the WHOLE mailbox every pass (not
  // just one message) so a backlog can't build up and start dropping
  // messages once the 8-slot mailbox fills.
  while (bean.available()) {
    bean.getMsg(bean_rx_buffer, RX_BUFFER_SIZE);

    // Print every BEAN message HEARD (received), including CRC status
    // ('R'=valid, 'E'=failed) - excludes 'T' entries, which are internal
    // ACK-response tracking for our own transmissions, not received data.
    if (bean_rx_buffer[1] == 'R' || bean_rx_buffer[1] == 'E') {
      Serial.print((char)bean_rx_buffer[1]);
      Serial.print(" ");
      for (int idx = 2; idx < bean_rx_buffer[0] + 2; idx++) {
        if (bean_rx_buffer[idx] < 0x10) {
          Serial.print("0"); // zero-pad single hex digits
        }
        Serial.print(bean_rx_buffer[idx], HEX);
        Serial.print(" ");
      }
      Serial.println();
    }

    checkBeanAcMessage();
    memset(bean_rx_buffer, 0, RX_BUFFER_SIZE);
  }

  uint32_t current_millis = millis();

  // --- Step 2 of the send sequence: once the temp message has cleared
  // the bus, send the lights message. Checked every loop pass instead of
  // blocking with delay(), so BEAN/CAN reception keeps running meanwhile.
  if (gaugeSendStep == 1 && !bean.isBusy()) {
    // --- Warning lights, now derived from CAN values + thresholds ---
    uint8_t g = 0;
    bool engineRunning = canRpm > 0;
    float chargeThreshold = engineRunning ? CHARGE_WARN_VOLTS_ENGINE_ON : CHARGE_WARN_VOLTS_ENGINE_OFF;
    if (canOilPressureKpa < OIL_PRESSURE_WARN_KPA) { g += 16; } // Oil Pressure (not gated by engineRunning, as you had it)
    if (canBattVolts < chargeThreshold) { g += 32; }            // Charge/alternator
    lights[2] = g;
    bean.sendMsg(lights, sizeof(lights));

    Serial.print("RPM "); Serial.print(canRpm);
    Serial.print(" OilP "); Serial.print(canOilPressureKpa);
    Serial.print("kPa Vbatt "); Serial.print(canBattVolts);
    Serial.print("V -> lights byte "); Serial.println(g, HEX);

    gaugeSendStep = 0; // cycle complete, ready to start again next second
  }

  // --- Step 1 of the send sequence: once a second, if the bus is free
  // and we're not already mid-sequence, send the temp message.
  if (current_millis - timer > 1000 && gaugeSendStep == 0) {
    if (!bean.isBusy()) {

      bool canDataStale = (current_millis - lastCanRxMillis) > 2000;
      if (canDataStale) {
        Serial.println("WARNING: no CAN data received recently - check wiring/bitrate/IDs");
      }

      // --- Temp gauge ---
      // NOTE: using your current +80.0f offset here, not the earlier
      // bench-confirmed +130.0f (90=-40C, 255=+125C) - flagging this in
      // case it wasn't an intentional recalibration.
      float gaugeVal = canCoolantC + 80.0f;
      if (gaugeVal < 90) gaugeVal = 90;
      if (gaugeVal > 255) gaugeVal = 255;
      engTemp[2] = (uint8_t)gaugeVal;
      if (engTemp[2] == 213) { engTemp[2] = 214; } // fixes weird needle drop at 213h
      bean.sendMsg(engTemp, sizeof(engTemp));

      Serial.print("CLT ");
      Serial.print(canCoolantC);
      Serial.print("C -> gauge ");
      Serial.println(engTemp[2]);

      gaugeSendStep = 1; // move to step 2 once the bus frees up again
      timer = current_millis;
    }
  }
}
